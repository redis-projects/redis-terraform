#!/bin/bash
# inventory-file should be updated with the new nodes
# the playbook will loop thru the inventory looking for nodes
# not currently in the cluster.  When found, a node will have 
# Redis Enterprise installed and will be added to the cluster
# multiple nodes can be added in one execution of the playbook
source ./source.sh

ansible-playbook -i $inventory_file redislabs-add-node.yaml -e @$extra_vars -e @$group_vars  -e re_url=$re_url
