source ./source.sh

ansible-playbook -i $inventory_file redislabs-secure-cluster.yaml -e @$extra_vars -e @$group_vars
