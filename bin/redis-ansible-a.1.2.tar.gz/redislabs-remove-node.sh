#!/bin/bash
# arg 1 should be the node id as shown in rladmin status
if [[ $# -ne 1 ]]; then
  echo "Usage: $0 node_id"
  exit
fi 
source ./source.sh

ansible-playbook -i $inventory_file redislabs-remove-node.yaml -e @$extra_vars -e @$group_vars -e "rmnode=$1"
