/opt/redislabs/bin/supervisorctl start dmc_proxy
