#!/bin/bash
#set -x
if [[ $# -ne 1 ]]; then
  echo "Usage: $0 node_name (as listed in inventory file)"
  exit
fi 
source ./source.sh

ansible-playbook -i $inventory_file print_vars.yaml -e @$extra_vars -e @$group_vars -e "hostname=$1"
