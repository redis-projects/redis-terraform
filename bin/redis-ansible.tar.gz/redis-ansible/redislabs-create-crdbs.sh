. source.sh
ansible-playbook -i $inventory_file redislabs-create-crdbs.yaml -e @$extra_vars -e @$crdbs_file
