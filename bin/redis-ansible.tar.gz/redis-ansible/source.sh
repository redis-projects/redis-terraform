# inventory name contains which invetory to use, can override it here
export INVENTORY_NAME=dmc-cluster
#export INVENTORY_NAME=test-inventory
export inventory_file=./inventories/${INVENTORY_NAME}.ini
#export extra_vars=./extra_vars/${INVENTORY_NAME}.yaml
export extra_vars=./extra_vars/${INVENTORY_NAME}.yaml

# make sure you have the right version of redis-enterprise software for your architecture 
#
# rhel7 - 6.0.6-39
#export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.0.6/redislabs-6.0.6-39-rhel7-x86_64.tar 
#
# rhel7 - 5.6.0-30
#export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/5.6.0/redislabs-5.6.0-30-rhel7-x86_64.tar 
#
# rhel7 - 5.4.14
#export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/5.4.14/redislabs-5.4.14-34-rhel7-x86_64.tar 
#
# ubuntu18.4 - 5.4.0-19
#export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/5.4.0/redislabs-5.4.0-19-bionic-amd64.tar
#
# ubuntu18.4 - 6.0.8-28
#export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.0.8/redislabs-6.0.8-28-bionic-amd64.tar
#
# ubuntu18.4 - 5.6.0-39
export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/5.6.0/redislabs-5.6.0-30-bionic-amd64.tar
#
export group_vars=./group_vars/all/main.yaml
export license_file=./licenses/license
#export certs_directory=./certs
export databases_file=./databases/databases.yaml
export crdbs_file=./crdbs/crdbs.yaml
