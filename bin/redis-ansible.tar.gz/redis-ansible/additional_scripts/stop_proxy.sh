/opt/redislabs/bin/supervisorctl stop dmc_proxy
