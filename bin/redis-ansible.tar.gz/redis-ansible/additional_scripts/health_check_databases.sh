echo "master of the cluster ip address: "
read MASTER_OF_CLUSTER_IP
echo "username: "
read USERNAME
echo "password: "
read -s PASSWORD

for i in `curl -s -X GET "https://${MASTER_OF_CLUSTER_IP}:9443/v1/bdbs" -k -u "${USERNAME}:${PASSWORD}" | jq .[].uid`
do
RESULT=`curl -s -X POST -H "Content-Type: application/json" -d '{ "command": "ping" }' https://${MASTER_OF_CLUSTER_IP}:9443/v1/bdbs/${i}/command -k -u ${USERNAME}:${PASSWORD} | jq .response`
echo "Database UID: ${i}, response: ${RESULT}"
done
