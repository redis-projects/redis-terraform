#!/bin/bash
if [ $# -lt 1 ]
then
  echo "USAGE: load_random_redis_data.sh {start_range} {end_range} {host} {port}"
else
read -s -p "Enter a Password for RedisDB: " PASSWORD
if [ -z "$PASSWORD" ]
  then
    echo "NO Password"
    time ruby gen_redis_protocol.rb $1 $2 | redis-cli -h $3 -p $4 --pipe
  else
    echo "Password"
    time ruby gen_redis_protocol.rb $1 $2 | redis-cli -h $3 -p $4 -a $5 --pipe
  fi
fi
