#!/bin/bash

export nodeid=`cat /etc/opt/redislabs/node.id`

/opt/redislabs/bin/rladmin status nodes |grep node:$nodeid  | grep -v 0/0 

if [ $? -eq 0 ]
then
/opt/redislabs/bin/rladmin node $nodeid maintenance_mode on
fi
