ansible-playbook redislabs-print-version.yaml -e@$group_vars
